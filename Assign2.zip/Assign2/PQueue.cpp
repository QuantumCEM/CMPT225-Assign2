/* 
 * File:   PQueue.h
 * Author: aka91
 * 
 * PQueue.h (and PQueue.cpp)
 * 
 * Class invariants: The elements stored in this Priority Queue are always sorted. 
 * Group: AC Soluctions
 *
 * Created on June 23, 2016, 1:45 PM
 */

#include <iostream>
#include <string>
#include "Event.h"
#include "Queue.h"
#include "PQueue.h"
#include "Node.h"

using namespace std;

// Description: Returns "true" is this Priority Queue is empty, otherwise "false".
// Time Efficiency: O(1)
bool PQueue::isEmpty() const
{
    
    return true;
}

// Description: Inserts newElement in sort order.
//              It returns "true" if successful, otherwise "false".
// Precondition: This Priority Queue is sorted.   
// Postcondition: Once newElement is inserted, this Priority Queue remains sorted.           
bool PQueue::enqueue(const Event& newElement)
{
    
    return true;
}

// Description: Removes the element with the "highest" priority.
//              It returns "true" if successful, otherwise "false".
// Precondition: This Priority Queue is not empty.
bool PQueue::dequeue()
{
    
    
    return true;
}

/*
// Description: Retrieves (but does not remove) the element with the "highest" priority.
// Precondition: This Priority Queue is not empty.
// Postcondition: This Priority Queue is unchanged.
// Exceptions: Throws EmptyDataCollectionException if this Priority Queue is empty.
Event PQueue::peek() const throw(EmptyDataCollectionException)    
{
    
    
    
}

 */